﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace LotoRotoProjekat1
{
    public class Class1
    {
        public static List<Int32> kombinacije = new List<int>();
    }
}